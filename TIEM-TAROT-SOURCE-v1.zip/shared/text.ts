/** Shared display/TTS pages. Prefer sentence endings without creating tiny pages. */
export function speechPages(text: string, maxWords = 24): string[] {
  const words = text.trim().split(/\s+/u).filter(Boolean);
  const pages: string[] = [];
  for (let start = 0; start < words.length; ) {
    let end = Math.min(start + maxWords, words.length);
    if (end < words.length) {
      for (
        let index = end - 1;
        index >= start + Math.ceil(maxWords * 0.55) - 1;
        index--
      ) {
        if (/[.!?…][”"')]*$/u.test(words[index])) {
          end = index + 1;
          break;
        }
      }
    }
    pages.push(words.slice(start, end).join(" "));
    start = end;
  }
  return pages;
}
