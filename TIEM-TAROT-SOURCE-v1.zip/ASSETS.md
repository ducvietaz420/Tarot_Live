# Tài sản hình ảnh

- `public/assets/cards/*.svg`: 78 minh họa vector biểu tượng tự biên soạn cho project. Dùng cấu trúc tarot truyền thống 22 Ẩn chính và bốn bộ 14 Ẩn phụ; không sao chép hình minh họa từ bộ bài thương mại. Tái tạo bằng `node scripts/generate-deck-assets.mjs`.
- `public/assets/card-back.svg`: mặt sau hình học tự biên soạn, cùng bảng màu tím, vàng và cyan.
- Nội dung tiếng Việt tại `shared/cards.ts`: lời gợi mở tự biên soạn, không dùng trích đoạn từ sách hay khẳng định dự đoán chắc chắn.
- Bộ bài hiện là minh họa biểu tượng thống nhất. Người vận hành có thể thay từng `cardAssets[cardId]` bằng artwork mình có quyền sử dụng trong admin. Không cần tải tài sản từ mạng khi đang phát.
- `public/assets/tarot-reader.png`: nhân vật nữ tarot hư cấu, trang phục nhung tím, được tạo riêng bằng công cụ image_gen tích hợp (không dùng CLI) với nền trong suốt. Prompt chính xác lưu ở `docs/CHARACTER-PROMPT.md`; không lấy ảnh người thật hoặc danh tính của ảnh tham chiếu.
- Nền sân khấu, vòm neon, lưới phối cảnh, sao và vòng huyền học được vẽ bằng CSS/SVG của project. Tài sản mặc định đều local, không cần ảnh/font/CDN khi phát. Nhân vật và nền có thể được thay bằng ảnh/video MP4/WebM riêng; tài sản từ URL ngoài do người vận hành chọn vẫn phụ thuộc kết nối mạng.
- `public/assets/avatars/`: 10 avatar người hư cấu và một avatar cộng đồng bằng SVG tự biên soạn; không lấy tên, ngày sinh hoặc avatar từ ảnh tham chiếu làm dữ liệu demo.

Các file SVG này là tài sản gốc của project, có thể sử dụng và chỉnh sửa cùng mã nguồn. Chúng không đại diện cho một bộ bài lịch sử đã được phục dựng.
