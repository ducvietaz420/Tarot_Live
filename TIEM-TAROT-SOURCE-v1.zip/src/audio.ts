import { useEffect, useRef, useState, type RefObject } from "react";
import type { Snapshot } from "../shared/types";
import { speechPages } from "../shared/text";

export function currentSpeech(state: Snapshot): string {
  const reading = state.session.active;
  if (!reading) return "";
  const index = ["card1", "card2", "card3"].indexOf(reading.phase);
  return index >= 0
    ? reading.content.cards[index]?.speech || ""
    : reading.phase === "summary"
      ? reading.content.summary
      : "";
}

/** An explicit, server-granted audio lease is required before this hook speaks. */
export function useAudio(
  state: Snapshot | null,
  socket: RefObject<WebSocket | null>,
  clientId: string,
) {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [status, setStatus] = useState("Chưa bật âm thanh");
  const [requesting, setRequesting] = useState(false);
  const audio = useRef<HTMLAudioElement | null>(null);
  const context = useRef<AudioContext | null>(null);
  const ambient = useRef<{
    gain: GainNode;
    oscillators: OscillatorNode[];
  } | null>(null);
  const pendingTest = useRef(false);
  const cursor = useRef({ phaseKey: "", index: 0 });
  const previousSfx = useRef("");
  const send = (message: object) => {
    if (socket.current?.readyState === WebSocket.OPEN)
      socket.current.send(JSON.stringify(message));
  };
  const report = (message: string) => {
    setStatus(message);
    send({ type: "audio-status", status: message });
  };
  const stop = () => {
    if ("speechSynthesis" in window) speechSynthesis.cancel();
    if (audio.current) {
      audio.current.pause();
      audio.current.src = "";
      audio.current = null;
    }
  };
  const getContext = () => {
    if (!context.current || context.current.state === "closed")
      context.current = new AudioContext();
    return context.current;
  };
  useEffect(() => {
    if (!("speechSynthesis" in window)) {
      setStatus("Trình duyệt không có giọng hệ thống");
      return;
    }
    const load = () => setVoices(speechSynthesis.getVoices());
    load();
    speechSynthesis.addEventListener("voiceschanged", load);
    return () => {
      speechSynthesis.removeEventListener("voiceschanged", load);
      stop();
      ambient.current?.oscillators.forEach((o) => o.stop());
      ambient.current = null;
      void context.current?.close();
      context.current = null;
    };
  }, []);
  const vi = voices.filter((v) => v.lang.toLowerCase().startsWith("vi"));
  const owner = state?.audioOwner === clientId;
  const busy = !!state?.audioOwnerMode && state.audioOwnerMode !== state.mode;
  const enable = async () => {
    if (busy) {
      setStatus(
        `Nguồn âm thanh đang ở phiên ${state!.audioOwnerMode!.toUpperCase()}. Tắt tại tab đó trước.`,
      );
      return;
    }
    setRequesting(true);
    try {
      await getContext().resume();
      send({ type: "audio-claim" });
    } catch {
      report("Không mở được thiết bị âm thanh của trình duyệt");
    }
    setTimeout(() => setRequesting(false), 1000);
  };
  const disable = () => {
    pendingTest.current = false;
    stop();
    send({ type: "audio-release" });
    setStatus("Đã tắt âm thanh ở tab này");
  };
  const testVoice = () => {
    if (!state) return;
    if (state.session.active && !state.session.active.paused) {
      report("Tạm dừng lượt hiện tại trước khi kiểm tra giọng");
      return;
    }
    if (!owner) {
      pendingTest.current = true;
      void enable();
      return;
    }
    const voice =
      voices.find(
        (v) =>
          v.voiceURI === state.config.voice &&
          v.lang.toLowerCase().startsWith("vi"),
      ) || vi[0];
    if (!voice) {
      report("Không tìm thấy giọng Việt. Chọn TTS HTTP hoặc chạy bằng chữ.");
      return;
    }
    stop();
    const utterance = new SpeechSynthesisUtterance(
      "Chào bạn, chào mừng đến với Tiệm Tarot. Chúc bạn một buổi tối an lành.",
    );
    utterance.voice = voice;
    utterance.lang = "vi-VN";
    utterance.rate = state.config.speechRate;
    utterance.volume = state.config.speechVolume;
    utterance.onend = () => report("Thử giọng thành công · " + voice.name);
    utterance.onerror = () =>
      report("Thử giọng bị lỗi hoặc bị trình duyệt chặn");
    speechSynthesis.speak(utterance);
    report("Đang thử giọng · " + voice.name);
  };
  const reading = state?.session.active;
  const token = reading
    ? `${state?.mode}:${reading.id}:${reading.phase}:${reading.generation}:${reading.paused}:${owner}`
    : `idle:${owner}`;
  useEffect(() => {
    stop();
    if (
      !state ||
      !reading ||
      !owner ||
      reading.paused ||
      reading.config.ttsProvider === "off"
    )
      return;
    const text = currentSpeech(state);
    if (!text) return;
    let stale = false;
    const abort = new AbortController();
    const phaseKey = `${reading.id}:${reading.phase}`;
    if (cursor.current.phaseKey !== phaseKey)
      cursor.current = { phaseKey, index: 0 };
    const pages = speechPages(text);
    if (cursor.current.index >= pages.length) cursor.current.index = 0;
    const signature = {
      readingId: reading.id,
      phase: reading.phase,
      generation: reading.generation || 0,
    };
    const segment = (index: number, value: string) => {
      if (!stale)
        send({ type: "audio-segment", ...signature, index, text: value });
    };
    const reserve = (seconds: number) => {
      if (!stale && Number.isFinite(seconds))
        send({
          type: "audio-duration",
          ...signature,
          seconds: Math.min(180, Math.max(1, seconds)),
        });
    };
    const finished = () => {
      if (!stale) {
        report("Đã đọc xong đoạn");
        send({ type: "audio-done", ...signature });
      }
    };
    const remainingEstimate = () =>
      pages.slice(cursor.current.index).join(" ").split(/\s+/).length /
        (2.5 * reading.config.speechRate) +
      5;
    reserve(remainingEstimate());

    if (reading.config.ttsProvider === "http") {
      const playPage = async (index: number): Promise<void> => {
        if (stale) return;
        if (index >= pages.length) {
          finished();
          return;
        }
        cursor.current.index = index;
        try {
          const response = await fetch(`/api/tts?mode=${state.mode}`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-Audio-Client": clientId,
            },
            body: JSON.stringify({ ...signature, segmentIndex: index }),
            signal: abort.signal,
          });
          if (!response.ok)
            throw new Error("TTS chưa cấu hình hoặc chưa sẵn sàng");
          const result = (await response.json()) as {
            url: string;
            text: string;
          };
          if (stale) return;
          const player = new Audio(result.url);
          audio.current = player;
          player.volume = reading.config.speechVolume;
          player.onloadedmetadata = () =>
            reserve(
              player.duration +
                pages
                  .slice(index + 1)
                  .join(" ")
                  .split(/\s+/).length /
                  (2.5 * reading.config.speechRate) +
                3,
            );
          player.onplay = () => {
            segment(index, result.text);
            report(`Đang đọc TTS · đoạn ${index + 1}/${pages.length}`);
          };
          player.onended = () => {
            if (!stale) {
              cursor.current.index = index + 1;
              void playPage(index + 1);
            }
          };
          player.onerror = () => {
            if (!stale) report("TTS lỗi · tiếp tục bằng chữ và thời gian giữ");
          };
          await player.play();
        } catch (error) {
          if (!stale && (error as Error).name !== "AbortError")
            report("TTS lỗi · tiếp tục bằng chữ và thời gian giữ");
        }
      };
      void playPage(cursor.current.index);
    } else {
      const voice =
        voices.find(
          (v) =>
            v.voiceURI === reading.config.voice &&
            v.lang.toLowerCase().startsWith("vi"),
        ) || vi[0];
      if (!voice) {
        report("Không có giọng Việt · đang chạy bằng chữ");
        return;
      }
      const speakPage = (index: number) => {
        if (stale) return;
        if (index >= pages.length) {
          finished();
          return;
        }
        cursor.current.index = index;
        reserve(remainingEstimate());
        const value = pages[index];
        const sentences = value
          .match(/[^.!?…]+(?:[.!?…]+|$)/gu)
          ?.map((s) => s.trim())
          .filter(Boolean) || [value];
        let lastSentence = "";
        const sentenceAt = (charIndex: number) => {
          let offset = 0;
          for (const sentence of sentences) {
            const start = value.indexOf(sentence, offset);
            if (charIndex < start + sentence.length) return sentence;
            offset = start + sentence.length;
          }
          return sentences.at(-1)!;
        };
        const utterance = new SpeechSynthesisUtterance(value);
        utterance.voice = voice;
        utterance.lang = "vi-VN";
        utterance.rate = reading.config.speechRate;
        utterance.volume = reading.config.speechVolume;
        utterance.onstart = () => {
          if (!stale) {
            lastSentence = sentences[0];
            segment(index, lastSentence);
            report(
              `Đang đọc · ${voice.name} · đoạn ${index + 1}/${pages.length}`,
            );
          }
        };
        utterance.onboundary = (event) => {
          const sentence = sentenceAt(event.charIndex);
          if (!stale && sentence !== lastSentence) {
            lastSentence = sentence;
            segment(index, sentence);
          }
        };
        utterance.onend = () => {
          if (!stale) {
            cursor.current.index = index + 1;
            speakPage(index + 1);
          }
        };
        utterance.onerror = (event) => {
          if (!stale && !["canceled", "interrupted"].includes(event.error))
            report("Giọng hệ thống lỗi · tiếp tục bằng chữ");
        };
        speechSynthesis.speak(utterance);
      };
      speakPage(cursor.current.index);
    }
    return () => {
      stale = true;
      abort.abort();
      stop();
    };
  }, [token, voices.length]);

  useEffect(() => {
    if (owner && pendingTest.current) {
      pendingTest.current = false;
      testVoice();
    }
  }, [owner]);

  useEffect(() => {
    if (!state || !owner) return;
    if (state.config.music && !ambient.current) {
      const ctx = getContext();
      const gain = ctx.createGain();
      gain.connect(ctx.destination);
      const oscillators = [110, 164.81, 220].map((frequency) => {
        const oscillator = ctx.createOscillator();
        oscillator.type = "sine";
        oscillator.frequency.value = frequency;
        oscillator.connect(gain);
        oscillator.start();
        return oscillator;
      });
      ambient.current = { gain, oscillators };
    }
    if (ambient.current && context.current)
      ambient.current.gain.gain.setTargetAtTime(
        state.config.music
          ? state.config.musicVolume *
              (reading && !reading.paused && currentSpeech(state) ? 0.035 : 0.1)
          : 0,
        context.current.currentTime,
        0.4,
      );
  }, [owner, token, state?.config.music, state?.config.musicVolume]);
  useEffect(() => {
    if (!owner && ambient.current && context.current)
      ambient.current.gain.gain.setTargetAtTime(
        0,
        context.current.currentTime,
        0.1,
      );
  }, [owner]);
  useEffect(() => {
    if (
      !owner ||
      !reading ||
      reading.paused ||
      !reading.config.sfx ||
      previousSfx.current === token
    )
      return;
    previousSfx.current = token;
    if (
      !["shuffling", "dealing", "card1", "card2", "card3"].includes(
        reading.phase,
      )
    )
      return;
    const ctx = getContext();
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(
      reading.phase === "shuffling" ? 240 : 660,
      ctx.currentTime,
    );
    oscillator.frequency.exponentialRampToValueAtTime(
      180,
      ctx.currentTime + 0.18,
    );
    gain.gain.setValueAtTime(
      0.025 * reading.config.speechVolume,
      ctx.currentTime,
    );
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);
    oscillator.connect(gain).connect(ctx.destination);
    oscillator.start();
    oscillator.stop(ctx.currentTime + 0.2);
  }, [token]);
  return {
    voices,
    vi,
    owner,
    enable,
    disable,
    test: testVoice,
    requesting,
    busy,
    status: owner
      ? status
      : busy
        ? `Nguồn âm thanh đang ở phiên ${state!.audioOwnerMode!.toUpperCase()}. Tắt tại tab đó trước.`
        : state?.audioOwner
          ? `Tab khác đang giữ âm thanh · ${state.audioStatus || ""}`
          : state?.audioStatus?.startsWith("DEMO:")
            ? state.audioStatus
            : status,
  };
}
