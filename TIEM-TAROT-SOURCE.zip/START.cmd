@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\START-WINDOWS.ps1" -KeepAlive
if errorlevel 1 pause

